<!DOCTYPE html>
<html>
<head>
    <title>Bootstrap Admin Template</title>
    <meta charset="UTF-8">
    <meta name="description" content="Creating admin dashboard">
    <meta name="keywords" content="HTML,CSS,Zalego,Technology,Zalego institute,JavaScript">
    <meta name="author" content="Your name">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- All our code. write here   --> 
    <?php
    require_once("includes/header.php");
    require_once("includes/sidebar.php");
    //Fetch all users records
    //1.database connection
    require_once('dbconnection.php');
    $fetchingEnrolledstudents= mysqli_query($conn,"SELECT*FROM enrollments");
    ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header bg-dark text-white text-center">
                            <span>Enrolled Students</span>
                            <span class="float-right">
                                <a href="addstudents.php" class="btn bt-secondary btn-sm">add student</a>
                            </span>
                        </div>
                        <div class="card-body">
                            <table class="table table-stripped table-hover table-responsive">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Name</th>
                                        <th>Reg Number</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>Course</th>
                                        <th>Enrolled On</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row=mysqli_fetch_array($fetchingEnrolledstudents)) {?>
                                <tr>
                                        <td><?php echo $row['id']?></td>
                                        <td><?php echo $row['name']?></td>
                                        <td><?php echo $row['reg_number']?></td>
                                        <td><?php echo $row['phone']?></td>
                                        <td><?php echo $row['email']?></td>
                                        <td><?php echo $row['course']?></td>
                                        <td><?php echo $row['created_at']?></td>
                                    <td>
                                        <a href="editstudents.php?id=<?php echo $row['id']?>" class="btn btn-primary btn-sm">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <a href="viewstudents.php?id=<?php echo $row['id']?>" class="btn btn-success btn-sm">
                                           <i class="fa fa-eye"></i>
                                        </a>
                                        <a href="deleteStudents.php?id=<?php echo $row['id']?>" class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                    <?php }?>                                 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>            
        </div>
    </div>   
<script src="jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>