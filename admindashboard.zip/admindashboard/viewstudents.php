<!DOCTYPE html>
<html>

<body>
    <!-- All our code. write here   -->
    
    <!-- sidebar here -->
    <?php
    require_once('includes/links.php');
    require_once('includes/header.php');
    require_once('includes/sidebar.php');

    // fetch all user records
    // 1. database connection
    require_once('dbconnection.php');
    //fetch students records using where
    $fetchEnrolledStudents=mysqli_query($conn,"SELECT * FROM enrollments WHERE id='".$_GET['id']."' ");
    while($row= mysqli_fetch_array($fetchEnrolledStudents)){
        $studentId= $row['id'];
        $studentsName= $row['name'];
        $studentsPhone= $row['phone'];
        $studentsEmail= $row['email'];
        $studentsRegNumber= $row['reg_number'];
        $studentsCourse= $row['course'];
        $studentsEnroled= $row['created_at'];
    }
    ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="caed-header bg-dark text-white text-center">
                            <span>Student Info</span>
                            <span class="float-left">
                                <i class="fa fa-user fa-lg"></i>
                            </span>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <li class="list-group-item">
                                    Name:<span><?php echo $studentsName?></span>
                                </li>
                                <li class="list-group-item">
                                    Registration No:<span><?php echo $studentsRegNumber?></span>
                                </li>
                                <li class="list-group-item">
                                    Phone:<span><?php echo $studentsPhone?></span>
                                </li>
                                <li class="list-group-item">
                                    Email:<span><?php echo $studentsEmail?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card">
                        <div class="caed-header bg-dark text-white text-center">
                            <span>Course Details</span>                            
                            <span class="float-left">
                                <i class="fa fa-folder-open fa-lg"></i>
                            </span>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <li class="list-group-item">
                                    Course Name:<span><?php echo $studentsCourse?></span>
                                </li>
                                <li class="list-group-item">
                                    Enrolled On:<span><?php echo $studentsEnroled?></span>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
<script src="jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
