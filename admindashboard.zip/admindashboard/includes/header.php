<div class="header">
        <img src="zalego.jpg" alt="zalego" height="50" width="50" class="rounded-circle" >
        <a href="#" class="navbar-trigger"><span></span></a>
    </div>