<div class="sidebar">
        <nav>
            <ul>
            <li>
                    <a href="index.php">
                        <span> <i class="fa fa-tachometer"></i></span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="students.php">
                        <span> <i class="fa fa-group"></i></span>
                        <span>Students</span>
                    </a>
                </li>
                <li>
                    <a href="">
                        <span> <i class="fa fa-folder-open"></i></span>
                        <span>Courses</span>
                    </a>
                </li>
                <li>
                    <a href="">
                        <span> <i class="fa fa-graduation-cap"></i></span>
                        <span>Campus</span>
                    </a>
                </li>
                <li>
                    <a href="Subscribers.php">
                        <span> <i class="fa fa-envelope"></i></span>
                        <span>Subscribers</span>
                    </a>
                </li>
                <li>
                    <a href="contactus.php">
                        <span> <i class="fa fa-envelope"></i></span>
                        <span>messages</span>
                    </a>
                </li>
            </ul>
        </nav>

    </div>